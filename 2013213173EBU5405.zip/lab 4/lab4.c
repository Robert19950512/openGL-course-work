
#define GLUT_DISABLE_ATEXIT_HACK
#include <windows.h>
#include<GL/glut.h>
#include <stdlib.h>


//color declearation 
 GLfloat colors[][3] = {{0.0,0.0,0.0},{0.0,1.0,0.0},
			{1.0,0.0,1.0}, {1.0,0.0,0.0}, {0.0,0.0,1.0},
			{1.0,1.0,0.0}};


//initialization function
void init(void)
{
   
    
    glClearColor(1,1,1,1);
    
 
    

}
//draw the body of the robot, it's a cube.
void draw_body(void)
{
    glPushMatrix();
    glTranslatef(0,1.5,0);
    glScalef(0.5,1,0.4);
   glColor3fv(colors[1]);

    glutSolidCube(4);
    glPopMatrix();
}
//draw the left shoulder of the robot
void draw_leftshoulder(void)
{
    glPushMatrix();
     glColor3fv(colors[2]);
    glTranslatef(1.5, 3,0);

    
    glTranslatef(0, -0.9, 0);
    glScalef(0.6, 1.3, 0.4);
    glutSolidCube(2);
    
    glScalef(1 / 0.4, 1 / 1, 1 / 0.5);
    glTranslatef(0, -1.4, 0);

    glutWireSphere(0.4, 200, 500);
    
    glScalef(0.4, 1, 0.5);
    glTranslatef(0, -1.4, 0);
    glutSolidCube(2);
    
    glScalef(0.7, 0.5, 0.4);
    glTranslatef(0, -3, 0);
    glutSolidCube(2);

    glPopMatrix();
}
//draw the right shoulder of the robot
void draw_rightshoulder(void)
{
    glPushMatrix();
      glColor3fv(colors[3]);
    glTranslatef(-1.5,2.7,0);
 
    
    glTranslatef(0,-0.5,0);
    glScalef(0.6, 1.3, 0.4);
    glutSolidCube(2);
    
    glScalef(1/0.4,1/1,1/0.5);
    glTranslatef(0,-1.4,0);

    glutWireSphere(0.4,200,500);
    
    glScalef(0.4,1,0.5);
    glTranslatef(0,-1.4,0);
    glutSolidCube(2);
    
    glScalef(0.7, 0.5, 0.4);
    glTranslatef(0, -3, 0);
    glutSolidCube(2);

    glPopMatrix();
}
//draw the head of the robot
void draw_head(void)
{
    glPushMatrix();
     glColor3fv(colors[4]);
    
    glTranslatef(0,3.5,0);

    glTranslatef(0,1,0);
  //  glutWireSphere(1,50,50);
  	glutSolidCube(1.4);
    
    glPopMatrix();
}
//draw the hair of the robot
void draw_hear(void)
{
    glPushMatrix();
     glColor3fv(colors[5]);
    
    glTranslatef(0,4.7,0);
  
    glTranslatef(0,1,0);
    glScalef(1,0.5,1);
  //  glutWireSphere(1,50,50);
  	glutSolidCube(1.4);
    
    glPopMatrix();
}
//draw leftfoot of the robot
void draw_leftfoot(void)
{
    glPushMatrix();
     glColor3fv(colors[6]);
    
    glTranslatef(-0.6,-0.6,0);
   
    glTranslatef(0,-1,0);
    glScalef(0.5,1.5,0.5);
    glutSolidCube(2);
    
    glScalef(1/0.4,1/1,1/0.5);
    glTranslatef(0,-1.4,0);
  
    glutWireSphere(0.4,200,500);
    
    glScalef(0.4,1,0.5);
    glTranslatef(0,-1.4,0);
    glutSolidCube(2);
    
    
    glScalef(1,1,1);
    glTranslatef(0,-1.15,0.75);
    glScalef(0.8,0.15,1.5);
    glutSolidCube(2);
    
    glPopMatrix();
}
//draw right foot of the robot
void draw_rightfoot(void)
{
    glPushMatrix();
     glColor3fv(colors[1]);
    
    glTranslatef(0.6,-0.6,0);
  
    glTranslatef(0,-1,0);
    glScalef(0.5,1.5,0.5);
    glutSolidCube(2);
    
    glScalef(1/0.4,1/1,1/0.5);
    glTranslatef(0,-1.4,0);

    glutWireSphere(0.4,200,500);
    
    glScalef(0.4,1,0.5);
    glTranslatef(0,-1.4,0);
    glutSolidCube(2);
    
    glScalef(1,1,1);
    glTranslatef(0,-1.15,0.75);
    glScalef(0.8,0.15,1.5);
    glutSolidCube(2);
    
    glPopMatrix();
}
//display function declearation
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glPushMatrix();
    
 
    
    glTranslatef(0,4,0);
    draw_body();
    
    draw_head();
    draw_hear();
    
    draw_leftshoulder();
    draw_rightshoulder();
    
    draw_leftfoot();
    draw_rightfoot();
    
    glPopMatrix();
    glutSwapBuffers();
}
//set the window size and camera
void reshape(int w,int h)
{
    glViewport(0,0,w,h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-20,20,-20,20,-20,20);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt (0.0, 8.0, 10, 0.0, 4, 0.0, 0.0, 1.0, 0.0);
}
//not using now
void human(unsigned char key,int x,int y)
{
   
}

//main function
int main(int argc,char** argv)
{
   
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RED| GLUT_DEPTH);
    glutInitWindowSize(600,600);
    glutInitWindowPosition(100,100);
    glutCreateWindow(argv[0]);
    init();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glEnable(GL_DEPTH_TEST);
    glutMainLoop();
     
    return 0;
}

