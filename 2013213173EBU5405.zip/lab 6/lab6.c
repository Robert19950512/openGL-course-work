
#define GLUT_DISABLE_ATEXIT_HACK
#include <windows.h>
#include<GL/glut.h>
#include <stdlib.h>
#include <math.h>

//delear the menu
int menu; 
//declear of the material of the body 
float no_mat[] = {0.0f, 0.0f, 0.0f, 1.0f};
float no_mat1[] = {1.0f, 1.0f, 0.0f, 1.0f};
float mat_ambient[] = {0.7f, 0.7f, 0.7f, 1.0f};
float mat_ambient_color[] = {0.8f, 0.8f, 0.2f, 1.0f};
float mat_diffuse[] = {0.1f, 0.5f, 0.8f, 1.0f};
float mat_diffuse1[] = {0.0f, 0.0f, 0.0f, 1.0f};
float mat_specular[] = {1.0f, 1.0f, 1.0f, 1.0f};
float no_shininess[] = {0.0f};
float low_shininess []= {5.0f};
float high_shininess []= {100.0f};
float mat_emission[] = {0.3f, 0.2f, 0.2f, 0.0f};
//declear some flag that is used to move the robot up/down
float uper = 0,gaodu = 0;
double x = 0.0;
//declear the flag and angle that is used for rotation 
static int angle = 0, angle1 = 0, neck = 0, lshoulder = 0, lelbow = 0, rshoulder = 0, relbow = 0, lft = 0, rft=0,
lhips = 0, rhips = 0, lfoot = 0, rfoot = 0, flagneck = 0, flaglshoulder = 0,t=0, cdflag=0, rflag=0, dflag=0,dkflag=0; 
flaglelbow = 0, flagrshoulder = 0, flagrelbow = 0, flaglhips = 0,
flagrhips = 0, flaglfoot = 0, flagrfoot = 0,flag = 0,flaglft = 1,flagrft = 1;

  //initialization function
void init(void)
{
    GLfloat ambient[]	= { 0.0, 0.0, 0.0, 1.0 };
    GLfloat diffuse[]	= { 1.0, 1.0, 1.0, 1.0 };
    GLfloat position[]	= { 0.0, 10.0, 0.0, 1.0 };
    GLfloat position1[]	= { 10.0, 5.0, 5.0, 1.0 };
    GLfloat specular[]  = {0.0 , 0.0 , 0.0 , 0.0};
    GLfloat lmodel_ambient[]	= { 0.4, 0.4, 0.4, 1.0 };
    GLfloat local_view[]		= { 0.0 };
    
    glClearColor(1,1,1,1);
    
    glLightfv(GL_LIGHT0, GL_AMBIENT, ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE, diffuse);
    glLightfv(GL_LIGHT0, GL_POSITION, position);
    glLightfv(GL_LIGHT0, GL_SPECULAR, specular);
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, lmodel_ambient);
    glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, local_view);
    
    glShadeModel(GL_SMOOTH);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_LIGHTING);
    glEnable(GL_LIGHT0);
   
    

}
//draw the body of the robot, it's a cube.
void draw_body(void)
{
    glPushMatrix();
    glTranslatef(0,1.5+uper*0.15,0);
    glScalef(0.5,1,0.4);
    glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient_color);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, no_mat1);

    glutSolidCube(4);
    glPopMatrix();
}
//draw the left shoulder of the robot
void draw_leftshoulder(void)
{
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
    glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
    glTranslatef(1.5, 3+uper*0.15,0);
    glRotatef(lshoulder, 1, 0, 0);
    
    glTranslatef(0, -0.9, 0);
    glScalef(0.6, 1.3, 0.4);
    glutSolidCube(2);
    
    glScalef(1 / 0.6, 1 / 1.3, 1 / 0.4);
    glTranslatef(0, -1.4, 0);
    glRotatef(lelbow, 1,0, 40);
    glutWireSphere(0.4, 200, 500);
    
    glScalef(0.4, 1*1.3, 0.5);
    glTranslatef(0, -1.4, 0);
    glutSolidCube(2);
    
    glScalef(0.7, 0.5, 0.4);
    glTranslatef(0, -3, 0);
    glutSolidCube(2);

    glPopMatrix();
}
//draw the right shoulder of the robot
void draw_rightshoulder(void)
{
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
    glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
    glTranslatef(-1.5,2.7+uper*0.15,0);
    glRotatef(rshoulder,1,0,0);
    
    glTranslatef(0,-0.5,0);
    glScalef(0.6, 1.3, 0.4);
    glutSolidCube(2);
    
   glScalef(1 / 0.6, 1 / 1.3, 1 / 0.4);
    glTranslatef(0,-1.4,0);
    glRotatef(relbow,1,0,0);
    glutWireSphere(0.4,200,500);
    
    glScalef(0.4,1.3,0.5);
    glTranslatef(0,-1.4,0);
    glutSolidCube(2);
    
    glScalef(0.7, 0.5, 0.4);
    glTranslatef(0, -3, 0);
    glutSolidCube(2);
    
     glTranslatef(0,3.5,0);
    glRotatef(neck,0,0,1);
    glTranslatef(0,1,0);
    	glutSolidCube(1.4);

    glPopMatrix();
}

//draw the head and hair of the robot

void draw_head(void)
{
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat1);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, low_shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
    
     glTranslatef(0,3+uper*0.15,0);
    glTranslatef(0,1,0);
    glScalef(0.7,0.6,0.6);
    glRotatef(neck,0,0,1);
  //  glutWireSphere(1,50,50);
  	glutSolidCube(2);
    
    glTranslatef(0,0.4,0);
    
    glTranslatef(0,1,0);
    glScalef(1,0.5,1);
  //  glutWireSphere(1,50,50);
  
   glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse1);
    glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
    glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
  	glColor3f(1.0f,1.0f,1.0f);
  	glutSolidCube(1.4);
    
    glPopMatrix();
}
//draw leftfoot of the robot
void draw_leftfoot(void)
{
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
    glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
    
    glTranslatef(-0.6,-0.7,0);
    glRotatef(lfoot,1,0,0);
    glTranslatef(0,-0.7+uper*0.3,uper*0.1);
    glScalef(0.5,1.5,0.5);
    glutSolidCube(2);
    
    glScalef(1/0.5,1/1.5,1/0.5);
   //  glScalef(1,1.7,1); 
    glTranslatef(0,-1.5,0);
    glRotatef(lhips,1,0,0);
    glutWireSphere(0.4,200,500);
   
     
    
    
    glTranslatef(0,-1.9,0);
    glScalef(0.4,1.5,0.5);
    glutSolidCube(2);
     glScalef(1/0.4,1/1.5,1/0.5); 
    
    
   
  
    glTranslatef(0,-1.35,0.4);
      glRotatef(lft,1,0,0);
    glScalef(0.4,0.15,1);
    
    
    glutSolidCube(2);
   
    glPopMatrix();
}
//draw right foot of the robot
void draw_rightfoot(void)
{
    glPushMatrix();
    glMaterialfv(GL_FRONT, GL_AMBIENT, no_mat);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR, no_mat);
    glMaterialfv(GL_FRONT, GL_SHININESS, no_shininess);
    glMaterialfv(GL_FRONT, GL_EMISSION, no_mat);
    
    glTranslatef(0.6,-0.7,0);
    glRotatef(rfoot,1,0,0);
    glTranslatef(0,-0.7+uper*0.3,uper*0.1);
    glScalef(0.5,1.5,0.5);
    glutSolidCube(2);
    
    glScalef(1/0.5,1/1.5,1/0.5);
    glTranslatef(0,-1.5,0);
    glRotatef(rhips,1,0,0);
    glutWireSphere(0.4,200,500);
    
    glTranslatef(0,-1.9,0);
    glScalef(0.4,1.5,0.5);
    glutSolidCube(2);
    
     glScalef(1/0.4,1/1.5,1/0.5); 
     
    glTranslatef(0,-1.35,0.4);
     glRotatef(rft,1,0,0);
    glScalef(0.4,0.15,1);
   
    glutSolidCube(2);
     
    
    glPopMatrix();
}
//display function declearation
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    glPushMatrix();
    
    glRotatef(angle,0,1,0);
    
    glTranslatef(0,4+gaodu,0+x);
    glRotatef(angle1,0,1,0);
    draw_body();
    
    draw_head();

    
    draw_leftshoulder();
    draw_rightshoulder();
    
    draw_leftfoot();
    draw_rightfoot();
    
    glPopMatrix();
    glutSwapBuffers();
}
//set the window size and camera
void reshape(int w,int h)
{
    glViewport(0,0,w,h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-20,20,-20,20,-20,20);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt (0.0, 8.0, 10, 0.0, 4, 0.0, 0.0, 1.0, 0.0);
}

//dunk motion
void idle(void){
	  if(dkflag==1){
  		if(flag==0){//dunk preparing motion
    	  		 lfoot-=1;
        	  lhips+=2;
        	   rfoot-=1;
        	  rhips+=2;
        	  if(lelbow!=-85){
        	  
        		lshoulder-=15;
        	  lelbow-=17;
      		  }
      		  if(rshoulder!=-27*6){
      		  
        	   rshoulder-=27;
        	  relbow-=10;
      		  }
        	  uper-=0.1;
        	  rft-=2;
        	  lft-=2;
        	   glutPostRedisplay();
        	if(lfoot<=-30)flag=1;
			 
			  }else if(flag==1){//rise+dunk 
			  	if(lfoot<=0){
					  	 lfoot+=5;
		        	  	lhips-=7;
						   lft+=5;
				   }
        		if(rfoot<=0){
						rfoot+=5;
		        	  rhips-=7;
		        	   rft+=5;
		        	 
      		  }
        	  if(uper>0)uper+=0.2;
        	  else uper=0;
			  if(gaodu<10.5){
			  gaodu+=1.4-0.1*t; 
			  t++;
			  
			  	}
			  		
			  		if(gaodu>10.5){
			  				if(angle<80)angle=(angle+2)%360;
			  		if(relbow<-20){
			  		relbow+=2;
			  		rshoulder+=3;
			  		}
			  		if(relbow>=-20){
					  
					  
					
					  if(angle>=80)flag=2;
					  }
			  		} 
			  		}
			  
			  	else if(flag==2){//launch
				  	if(gaodu>0)
					  {	
					  		gaodu+=1.4-0.05*t; 
				  			t++;
				  		}
				   if(lfoot<0)lfoot+=2.5;
        	  if(lhips>0)lhips-=5;
        	   if(rfoot<0)rfoot+=2.5;
        	  if(rhips>0)rhips-=5;
        	  if(lelbow!=0){
        	  
        		lshoulder+=3;
        	  lelbow+=5;
      		  }
      		  if(rshoulder<=0)
      		  
        	   rshoulder+=5;
        	 
      		  
      		  if(relbow<=0) relbow+=5;
        	  
        	  rft=0;
        	  lft=0;
        	  //re initialization
				  if(gaodu<=0){
				  uper = 0,gaodu = 0;
				  angle = 0, neck = 0, lshoulder = 0, lelbow = 0, rshoulder = 0, relbow = 0, lft = 0, rft=0,
					lhips = 0, rhips = 0, lfoot = 0, rfoot = 0, flagneck = 0, flaglshoulder = 0,t=0,
					flaglelbow = 0, flagrshoulder = 0, flagrelbow = 0, flaglhips = 0,
					flagrhips = 0, flaglfoot = 0, flagrfoot = 0,flag = 0,flaglft = 1,flagrft = 1;
				  }
				  
				  }
			  	 glutPostRedisplay();
			
        }
		if(cdflag==1){
				x=3;
			 angle=(angle+5)%360;
			   glutPostRedisplay();}
		if(dflag==1){	
			if(flagneck)
	            {
	                neck=neck+5;
	                if(neck>=30)flagneck=0;
	            }
	            else{
	                neck=neck-5;
	                if(neck<=-30)flagneck=1;
	            }
            glutPostRedisplay();}
        if(rflag==1){ 
			angle=(angle+5)%360;
		    glutPostRedisplay();
        }
       
		
}
//left mouse used to control the motion status of the robot
void mymouse(int button, int state, int x, int y){
	if(button == GLUT_LEFT_BUTTON&&state==GLUT_UP)dkflag=!dkflag;
	
}
//create a menu
void GetCurrentMenu(void)
{
int nMenu;
nMenu=glutGetMenu();
if(nMenu == menu)
 1;
}
//main function
int main(int argc,char** argv)
{
   
    glutInit(&argc,argv);
    glutInitDisplayMode(GLUT_DOUBLE|GLUT_RED| GLUT_DEPTH);
    glutInitWindowSize(600,600);
    glutInitWindowPosition(100,100);
    glutCreateWindow(argv[0]);
    init();
 //    gluLookAt(3.0, 3.0, 3.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);

    glutIdleFunc(idle);
    glutMouseFunc(mymouse); 

    glutMainLoop();
     glEnable(GL_DEPTH_TEST);
    return 0;
}

